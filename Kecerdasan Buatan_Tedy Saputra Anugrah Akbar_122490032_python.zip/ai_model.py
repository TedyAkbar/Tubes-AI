import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report
import joblib
import os
import glob
from sklearn.metrics import confusion_matrix, f1_score

class ProductDefectPredictor:
    def __init__(self):
        self.model = None
        self.scaler = None
        self.model_path = 'defect_predictor_model.joblib'
        self.scaler_path = 'scaler.joblib'
        
    def load_model(self):
        """Memuat model dan scaler yang sudah dilatih"""
        if os.path.exists(self.model_path) and os.path.exists(self.scaler_path):
            self.model = joblib.load(self.model_path)
            self.scaler = joblib.load(self.scaler_path)
            return True
        return False
    
    def train_model(self, data_path, model_name=None, validation_type=None, progress_callback=None, total_epoch=10):
        """Melatih model dengan data baru dan progress epoch"""
        try:
            # Baca data
            if data_path.endswith('.xlsx'):
                df = pd.read_excel(data_path)
            else:
                df = pd.read_csv(data_path)
            
            # Preprocessing
            X = df[['suhu', 'pressure', 'kemiringan']]
            y = df['label']  # 0: normal, 1: cacat
            
            # Split data
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
            
            # Scaling
            self.scaler = StandardScaler()
            X_train_scaled = self.scaler.fit_transform(X_train)
            X_test_scaled = self.scaler.transform(X_test)
            
            # Simulasi training per-epoch (hanya untuk progress bar)
            for epoch in range(1, total_epoch+1):
                # (RandomForest tidak support partial_fit, jadi ini hanya simulasi epoch)
                if progress_callback:
                    progress_callback(50 + int(40*epoch/total_epoch), epoch)
            
            # Training model (sekali saja)
            self.model = RandomForestClassifier(n_estimators=100, random_state=42)
            self.model.fit(X_train_scaled, y_train)
            
            # Evaluasi
            y_pred = self.model.predict(X_test_scaled)
            accuracy = accuracy_score(y_test, y_pred)
            report = classification_report(y_test, y_pred)
            
            # Simpan model dan scaler dengan nama sesuai input user
            if model_name:
                model_dir = "model_ai"
                if not os.path.exists(model_dir):
                    os.makedirs(model_dir)
                model_path = os.path.join(model_dir, f"{model_name}.pkl")
                scaler_path = os.path.join(model_dir, f"{model_name}_scaler.pkl")
                # Simpan data uji/validasi ke pkl
                testdata_path = os.path.join(model_dir, f"{model_name}_testdata.pkl")
                joblib.dump({'X_test': X_test, 'y_test': y_test}, testdata_path)
            else:
                model_path = self.model_path
                scaler_path = self.scaler_path
            joblib.dump(self.model, model_path)
            joblib.dump(self.scaler, scaler_path)
            
            return True, ""
            
        except Exception as e:
            return False, str(e)
    
    def predict(self, input_data):
        """Memprediksi cacat produk berdasarkan input DataFrame dengan kolom ['suhu', 'pressure', 'kemiringan']"""
        if self.model is None or self.scaler is None:
            return "Model belum dilatih"
        try:
            input_scaled = self.scaler.transform(input_data)
            prediction = self.model.predict(input_scaled)[0]
            probability = self.model.predict_proba(input_scaled)[0]
            result = {
                'prediction': 'Cacat' if prediction == 1 else 'Normal',
                'confidence': probability[1] if prediction == 1 else probability[0]
            }
            return result
        except Exception as e:
            return f"Error dalam prediksi: {str(e)}"
    
    def evaluate_model(self, model_name):
        """Evaluasi model yang sudah disimpan berdasarkan nama model"""
        try:
            model_dir = "model_ai"
            model_path = os.path.join(model_dir, f"{model_name}")
            scaler_path = os.path.join(model_dir, f"{model_name.replace('.pkl', '_scaler.pkl')}")
            testdata_path = os.path.join(model_dir, f"{model_name.replace('.pkl', '_testdata.pkl')}")
            if not os.path.exists(model_path) or not os.path.exists(scaler_path):
                return {'error': 'Model atau scaler tidak ditemukan'}
            if not os.path.exists(testdata_path):
                return {'error': 'File data uji/validasi (.pkl) untuk model ini tidak ditemukan di folder model_ai. Silakan lakukan training ulang.'}
            # Load model, scaler, dan data uji
            self.model = joblib.load(model_path)
            self.scaler = joblib.load(scaler_path)
            testdata = joblib.load(testdata_path)
            X_test = testdata['X_test']
            y_test = testdata['y_test']
            X_test_scaled = self.scaler.transform(X_test)
            y_pred = self.model.predict(X_test_scaled)
            # Probabilitas kelas
            if hasattr(self.model, 'predict_proba'):
                proba = self.model.predict_proba(X_test_scaled)
                class_labels = self.model.classes_
                avg_proba = proba.mean(axis=0)
                probabilities = {str(label): float(avg_proba[i]) for i, label in enumerate(class_labels)}
            else:
                probabilities = {}
            # Confusion matrix dan metrik hanya untuk label 1, 2, 3
            from sklearn.metrics import confusion_matrix, f1_score, classification_report, accuracy_score
            labels = [1, 2, 3]
            string_labels = ['Cacat Berat', 'Cacat Ringan', 'Bagus']
            cm = confusion_matrix(y_test, y_pred, labels=labels)
            accuracy = accuracy_score(y_test, y_pred)
            f1 = f1_score(y_test, y_pred, labels=labels, average='weighted', zero_division=0)
            report = classification_report(y_test, y_pred, labels=labels, target_names=string_labels, zero_division=0)
            return {
                'probabilities': probabilities,
                'confusion_matrix': cm,
                'confusion_labels': string_labels,
                'accuracy': accuracy,
                'f1_score': f1,
                'report': report
            }
        except Exception as e:
            return {'error': str(e)} 