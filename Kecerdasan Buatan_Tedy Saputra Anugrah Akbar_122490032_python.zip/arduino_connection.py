from PyQt5.QtWidgets import (QDialog, QFormLayout, QComboBox, 
                           QDoubleSpinBox, QPushButton, QHBoxLayout)
from PyQt5.QtCore import Qt
import serial.tools.list_ports

class ArduinoConnectionDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Koneksi Arduino")
        self.setGeometry(200, 200, 400, 300)
        
        # Set style
        self.setStyleSheet("""
            QDialog {
                background-color: #f0f0f0;
            }
            QLabel {
                font-size: 12px;
                color: #333;
            }
            QComboBox, QDoubleSpinBox {
                padding: 5px;
                border: 1px solid #ccc;
                border-radius: 3px;
                background-color: white;
            }
            QPushButton {
                padding: 5px 15px;
                background-color: #4CAF50;
                color: white;
                border: none;
                border-radius: 3px;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
        """)
        
        layout = QFormLayout()
        
        self.port_combo = QComboBox()
        self.refresh_ports()
        
        self.baudrate = QComboBox()
        self.baudrate.addItems(["9600", "19200", "38400", "57600", "115200"])
        
        self.suhu_target = QDoubleSpinBox()
        self.suhu_target.setRange(0, 200)
        self.suhu_target.setSuffix(" °C")
        
        self.pressure_target = QDoubleSpinBox()
        self.pressure_target.setRange(0, 1000)
        self.pressure_target.setSuffix(" kPa")
        
        self.kemiringan_target = QDoubleSpinBox()
        self.kemiringan_target.setRange(0, 90)
        self.kemiringan_target.setSuffix(" °")
        
        layout.addRow("Port:", self.port_combo)
        layout.addRow("Baud Rate:", self.baudrate)
        layout.addRow("Suhu Target:", self.suhu_target)
        layout.addRow("Pressure Target:", self.pressure_target)
        layout.addRow("Kemiringan Target:", self.kemiringan_target)
        
        buttons = QHBoxLayout()
        connect_btn = QPushButton("Connect")
        disconnect_btn = QPushButton("Disconnect")
        cancel_btn = QPushButton("Cancel")
        
        connect_btn.clicked.connect(self.connect_arduino)
        disconnect_btn.clicked.connect(self.disconnect_arduino)
        cancel_btn.clicked.connect(self.reject)
        
        buttons.addWidget(connect_btn)
        buttons.addWidget(disconnect_btn)
        buttons.addWidget(cancel_btn)
        
        layout.addRow(buttons)
        self.setLayout(layout)
    
    def refresh_ports(self):
        self.port_combo.clear()
        ports = [port.device for port in serial.tools.list_ports.comports()]
        self.port_combo.addItems(ports)
    
    def connect_arduino(self):
        # Implementasi koneksi Arduino
        pass
    
    def disconnect_arduino(self):
        # Implementasi disconnect Arduino
        pass
    
    def get_settings(self):
        return {
            'port': self.port_combo.currentText(),
            'baudrate': int(self.baudrate.currentText()),
            'suhu_target': self.suhu_target.value(),
            'pressure_target': self.pressure_target.value(),
            'kemiringan_target': self.kemiringan_target.value()
        } 