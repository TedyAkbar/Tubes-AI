import pandas as pd
import numpy as np
from datetime import datetime
import random

def generate_real_data(n, filename):
    # Rentang suhu (ambil acak dari salah satu rentang per baris)
    suhu_ranges = [
        (180, 200),  # Rear
        (190, 205),  # Middle
        (190, 210),  # Front
        (195, 210),  # Nozzle
        (200, 215),  # Melting
    ]
    # Pressure: 3-15 MPa -> 30-150 bar
    pressure_min, pressure_max = 30, 150
    # Kemiringan: 15-45 derajat
    kemiringan_min, kemiringan_max = 15, 45

    # Label: 1=30%, 2=30%, 3=40%
    labels = [1]*int(n*0.3) + [2]*int(n*0.3) + [3]*(n - int(n*0.3)*2)
    random.shuffle(labels)

    data = []
    for i in range(n):
        suhu_rng = random.choice(suhu_ranges)
        suhu = round(np.random.uniform(*suhu_rng), 2)
        pressure = round(np.random.uniform(pressure_min, pressure_max), 2)
        kemiringan = round(np.random.uniform(kemiringan_min, kemiringan_max), 2)
        label = labels[i]
        data.append([suhu, pressure, kemiringan, label])

    df = pd.DataFrame(data, columns=['suhu', 'pressure', 'kemiringan', 'label'])
    df['banyak_data'] = n
    df['tipe_data'] = 'data real'
    df['tanggal'] = datetime.now().strftime('%Y-%m-%d')
    df.to_excel(filename, index=False)
    print(f"File {filename} berhasil dibuat.")

def generate_sampah_data(n, filename):
    # Rentang normal
    suhu_ranges = [
        (180, 200), (190, 205), (190, 210), (195, 210), (200, 215)
    ]
    pressure_min, pressure_max = 30, 150
    kemiringan_min, kemiringan_max = 15, 45

    data = []
    for i in range(n):
        tipe = random.choice(['outlier', 'pola_aneh', 'label_kosong'])
        if tipe == 'outlier':
            # Suhu, pressure, kemiringan di luar rentang normal
            suhu = round(np.random.uniform(100, 300), 2)
            while any(r[0] <= suhu <= r[1] for r in suhu_ranges):
                suhu = round(np.random.uniform(100, 300), 2)
            pressure = round(np.random.uniform(0, 300), 2)
            while pressure_min <= pressure <= pressure_max:
                pressure = round(np.random.uniform(0, 300), 2)
            kemiringan = round(np.random.uniform(0, 90), 2)
            while kemiringan_min <= kemiringan <= kemiringan_max:
                kemiringan = round(np.random.uniform(0, 90), 2)
            label = random.choice([1, 2, 3])
        elif tipe == 'pola_aneh':
            # Kombinasi tidak masuk akal (misal suhu sangat tinggi, pressure sangat rendah)
            suhu = round(np.random.uniform(250, 300), 2)
            pressure = round(np.random.uniform(0, 20), 2)
            kemiringan = round(np.random.uniform(0, 90), 2)
            label = random.choice([1, 2, 3])
        else:  # label_kosong
            suhu_rng = random.choice(suhu_ranges)
            suhu = round(np.random.uniform(*suhu_rng), 2)
            pressure = round(np.random.uniform(pressure_min, pressure_max), 2)
            kemiringan = round(np.random.uniform(kemiringan_min, kemiringan_max), 2)
            label = ''
        data.append([suhu, pressure, kemiringan, label])

    df = pd.DataFrame(data, columns=['suhu', 'pressure', 'kemiringan', 'label'])
    df['banyak_data'] = n
    df['tipe_data'] = 'data sampah'
    df['tanggal'] = datetime.now().strftime('%Y-%m-%d')
    df.to_excel(filename, index=False)
    print(f"File {filename} berhasil dibuat.")

if __name__ == "__main__":
    # Data real
    generate_real_data(100, "data_real_100.xlsx")
    generate_real_data(500, "data_real_500.xlsx")
    generate_real_data(1000, "data_real_1000.xlsx")
    # Data sampah
    generate_sampah_data(100, "data_sampah_100.xlsx")
    generate_sampah_data(500, "data_sampah_500.xlsx")
