import pyodbc
from datetime import datetime

class Database:
    def __init__(self):
        try:
            # Koneksi ke SQL Server menggunakan format string yang berbeda
            server = 'DESKTOP-47MK38B\\TEW_SQLEXPRESS'
            database = 'cetakan_db'
            conn_str = f'DRIVER={{SQL Server}};SERVER={server};DATABASE={database};Trusted_Connection=yes;'
            
            self.conn = pyodbc.connect(conn_str)
            self.cursor = self.conn.cursor()
            self.init_database()
        except pyodbc.Error as e:
            print(f"Error koneksi database: {str(e)}")
            raise
    
    def init_database(self):
        try:
            # Tabel data cetakan
            self.cursor.execute('''
                IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='data_cetakan' AND xtype='U')
                CREATE TABLE data_cetakan (
                    id INT IDENTITY(1,1) PRIMARY KEY,
                    suhu FLOAT,
                    pressure FLOAT,
                    kemiringan FLOAT,
                    cetakan_ke INT,
                    timestamp DATETIME,
                    username VARCHAR(50),
                    label INT
                )
            ''')
            
            # Tabel user
            self.cursor.execute('''
                IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='users' AND xtype='U')
                CREATE TABLE users (
                    id INT IDENTITY(1,1) PRIMARY KEY,
                    username VARCHAR(50) UNIQUE,
                    password VARCHAR(100),
                    role VARCHAR(20),
                    created_at DATETIME
                )
            ''')
            
            self.conn.commit()
        except pyodbc.Error as e:
            print(f"Error inisialisasi database: {str(e)}")
            raise
    
    def validate_login(self, username, password):
        try:
            # Debug: Cetak username dan password yang diinput
            print(f"Username yang diinput: {username}")
            print(f"Password yang diinput: {password}")
            
            # Query untuk mendapatkan data user
            self.cursor.execute('''
                SELECT username, password, role FROM users 
                WHERE username = ? AND password = ?
            ''', (username, password))
            
            result = self.cursor.fetchone()
            
            # Debug: Cetak hasil query
            if result:
                print(f"Data dari database - Username: {result[0]}, Password: {result[1]}, Role: {result[2]}")
                return result[2]  # Return role
            else:
                print("User tidak ditemukan di database")
                return None
            
        except pyodbc.Error as e:
            print(f"Error validasi login: {str(e)}")
            return None
    
    def add_user(self, username, password, role):
        try:
            self.cursor.execute('''
                INSERT INTO users (username, password, role, created_at)
                VALUES (?, ?, ?, ?)
            ''', (username, password, role, datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
            self.conn.commit()
            return True
        except pyodbc.IntegrityError:
            print("Username sudah ada")
            return False
        except pyodbc.Error as e:
            print(f"Error menambahkan user: {str(e)}")
            return False
    
    def save_data(self, data, username):
        for i in range(data['jumlah_cetakan']):
            self.cursor.execute('''
                INSERT INTO data_cetakan (suhu, pressure, kemiringan, cetakan_ke, 
                                        timestamp, username, label)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (data['suhu'], data['pressure'], data['kemiringan'], i+1,
                 datetime.now().strftime('%Y-%m-%d %H:%M:%S'), username, data['label']))
        self.conn.commit()
    
    def get_all_data(self):
        self.cursor.execute('SELECT * FROM data_cetakan')
        return self.cursor.fetchall()
    
    def close(self):
        self.conn.close() 