from PyQt5.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, 
                           QLabel, QPushButton, QGridLayout, QFrame,
                           QMessageBox, QTableWidget, QTableWidgetItem,
                           QDialog, QScrollArea, QHBoxLayout, QComboBox,
                           QLineEdit, QFormLayout, QHeaderView, QTextEdit,
                           QFileDialog, QProgressBar, QInputDialog, QSizePolicy)
from PyQt5.QtCore import Qt, QPropertyAnimation, QEasingCurve, QSize, QTimer
from PyQt5.QtGui import QFont, QIcon, QPixmap
from database import Database
from styles import APP_STYLE
import pandas as pd
import json
import sys
import serial.tools.list_ports
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import numpy as np
from PyQt5.QtWidgets import QApplication
import os
import joblib

class ArduinoConnectionDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Koneksi Arduino")
        self.setGeometry(200, 200, 400, 200)
        
        layout = QVBoxLayout()
        
        # Form untuk port dan baudrate
        form_layout = QFormLayout()
        
        # Port selection
        self.port_combo = QComboBox()
        self.refresh_ports()
        form_layout.addRow("Port:", self.port_combo)
        
        # Baudrate selection
        self.baudrate_combo = QComboBox()
        self.baudrate_combo.addItems([
            "300", "600", "1200", "2400", "4800", "9600",
            "14400", "19200", "28800", "38400", "57600",
            "115200", "230400", "250000", "500000", "1000000"
        ])
        self.baudrate_combo.setCurrentText("9600")  # Set default baudrate
        form_layout.addRow("Baudrate:", self.baudrate_combo)
        
        layout.addLayout(form_layout)
        
        # Tombol
        button_layout = QHBoxLayout()
        self.connect_btn = QPushButton("Connect")
        self.cancel_btn = QPushButton("Cancel")
        
        self.connect_btn.clicked.connect(self.connect_arduino)
        self.cancel_btn.clicked.connect(self.reject)
        
        button_layout.addWidget(self.connect_btn)
        button_layout.addWidget(self.cancel_btn)
        
        layout.addLayout(button_layout)
        self.setLayout(layout)
        
        self.serial_port = None
        
    def refresh_ports(self):
        self.port_combo.clear()
        ports = serial.tools.list_ports.comports()
        for port in ports:
            self.port_combo.addItem(port.device)
            
    def connect_arduino(self):
        try:
            port = self.port_combo.currentText()
            baudrate = int(self.baudrate_combo.currentText())
            
            self.serial_port = serial.Serial(port, baudrate)
            QMessageBox.information(self, "Sukses", "Berhasil terhubung ke Arduino")
            self.accept()
            
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Gagal terhubung: {str(e)}")
        
    def closeEvent(self, event):
        if self.serial_port and self.serial_port.is_open:
            self.serial_port.close()
        event.accept()

class AdvancedParameterDialog(QDialog):
    def __init__(self, parent=None, epochs='', batch_size='', lr='', optimizer='', loss='', activation=''):
        super().__init__(parent)
        self.setWindowTitle("Parameter Tambahan")
        layout = QFormLayout(self)
        # Epochs
        self.epoch_input = QLineEdit(epochs)
        self.epoch_input.setToolTip("Jumlah pengulangan seluruh data training yang digunakan untuk melatih model. Semakin besar, model akan belajar lebih lama.")
        layout.addRow("Epochs:", self.epoch_input)
        # Batch Size
        self.batch_input = QLineEdit(batch_size)
        self.batch_input.setToolTip("Jumlah data yang diproses sekaligus sebelum model memperbarui bobotnya. Batch size kecil update lebih sering, batch besar lebih efisien untuk data besar.")
        layout.addRow("Batch Size:", self.batch_input)
        # Learning Rate
        self.lr_input = QLineEdit(lr)
        self.lr_input.setToolTip("Besarnya langkah perubahan bobot model pada setiap update. Nilai kecil membuat proses belajar lebih lambat tapi stabil, nilai besar bisa membuat model tidak stabil.")
        layout.addRow("Learning Rate:", self.lr_input)
        # Optimizer
        self.optimizer_combo = QComboBox()
        self.optimizer_combo.addItems(["SGD", "Adam", "RMSprop"])
        if optimizer:
            idx = self.optimizer_combo.findText(optimizer)
            if idx >= 0:
                self.optimizer_combo.setCurrentIndex(idx)
        self.optimizer_combo.setToolTip("Algoritma yang digunakan untuk mengatur proses update bobot model selama training.")
        layout.addRow("Optimizer:", self.optimizer_combo)
        # Loss Function
        self.loss_combo = QComboBox()
        self.loss_combo.addItems(["Binary Crossentropy", "Categorical Crossentropy", "MSE"])
        if loss:
            idx = self.loss_combo.findText(loss)
            if idx >= 0:
                self.loss_combo.setCurrentIndex(idx)
        self.loss_combo.setToolTip("Fungsi yang mengukur seberapa jauh prediksi model dari nilai sebenarnya. Loss function digunakan sebagai dasar untuk memperbaiki bobot model.")
        layout.addRow("Loss Function:", self.loss_combo)
        # Activation Function
        self.activation_combo = QComboBox()
        self.activation_combo.addItems(["ReLU", "Sigmoid", "Tanh"])
        if activation:
            idx = self.activation_combo.findText(activation)
            if idx >= 0:
                self.activation_combo.setCurrentIndex(idx)
        self.activation_combo.setToolTip("Fungsi matematika yang digunakan di setiap neuron/lapisan pada jaringan saraf. Membantu model mempelajari pola yang kompleks.")
        layout.addRow("Activation Function:", self.activation_combo)
        # Tombol OK dan Cancel
        btn_layout = QHBoxLayout()
        ok_btn = QPushButton("OK")
        cancel_btn = QPushButton("Cancel")
        ok_btn.clicked.connect(self.accept)
        cancel_btn.clicked.connect(self.reject)
        btn_layout.addWidget(ok_btn)
        btn_layout.addWidget(cancel_btn)
        layout.addRow(btn_layout)
    def get_values(self):
        return {
            'epochs': self.epoch_input.text(),
            'batch_size': self.batch_input.text(),
            'lr': self.lr_input.text(),
            'optimizer': self.optimizer_combo.currentText(),
            'loss': self.loss_combo.currentText(),
            'activation': self.activation_combo.currentText(),
        }

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Sistem Pencetakan Biji Catur")
        
        # Set ukuran window yang lebih kecil dan mepet ke atas
        screen = QApplication.desktop().screenGeometry()
        window_width = 1200
        window_height = 700  # Tinggi window dikurangi
        
        # Hitung posisi x agar di tengah layar
        x = (screen.width() - window_width) // 2
        self.setGeometry(x, 0, window_width, window_height)  # Posisi x di tengah, y=0 untuk mepet ke atas
        
        # Set window icon
        self.setWindowIcon(QIcon("logo.png"))
        
        # Inisialisasi database
        self.db = Database()
        
        # Set style
        self.setStyleSheet(APP_STYLE)
        
        # Inisialisasi nilai default parameter tambahan
        self.epoch_value = "10"
        self.batch_value = "32"
        self.lr_value = "0.001"
        self.optimizer_value = "Adam"
        self.loss_value = "Categorical Crossentropy"
        self.activation_value = "ReLU"
        
        # Langsung tampilkan menu utama
        self.show_main_menu()
    
    def center_window(self):
        # Dapatkan ukuran layar
        screen = QApplication.desktop().screenGeometry()
        # Dapatkan ukuran window
        size = self.geometry()
        # Hitung posisi tengah horizontal, tapi tetap di atas
        x = (screen.width() - size.width()) // 2
        y = 0  # Posisi y=0 untuk mepet ke atas
        # Set posisi window
        self.move(x, y)
    
    def show_main_menu(self):
        # Hentikan timer sebelumnya jika ada
        if hasattr(self, 'timer'):
            self.timer.stop()
            
        # Widget utama
        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)
        
        # Scroll area untuk konten
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("QScrollArea { border: none; }")
        
        # Layout utama
        main_layout = QVBoxLayout(self.central_widget)
        main_layout.setSpacing(20)
        main_layout.setContentsMargins(20, 20, 20, 20)
        
        # Header dengan logo dan judul
        header_frame = QFrame()
        header_frame.setStyleSheet("""
            QFrame {
                background-color: #2196F3;
                border-radius: 12px;
                padding: 20px;
            }
        """)
        header_layout = QHBoxLayout(header_frame)
        header_layout.setSpacing(20)
        
        # Logo
        logo_label = QLabel()
        logo_pixmap = QPixmap("logo.png")
        if not logo_pixmap.isNull():
            logo_pixmap = logo_pixmap.scaled(80, 80, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            logo_label.setPixmap(logo_pixmap)
        else:
            logo_label.setText("LOGO")
            logo_label.setStyleSheet("font-size: 24px; font-weight: bold; color: white;")
        header_layout.addWidget(logo_label)
        
        # Judul dan waktu
        title_time_layout = QVBoxLayout()
        
        # Judul
        title = QLabel("Sistem Pencetakan Biji Catur")
        title.setStyleSheet("""
            QLabel {
                font-size: 28px;
                font-weight: bold;
                color: white;
            }
        """)
        title_time_layout.addWidget(title)
        
        # Subtitle
        subtitle = QLabel("Monitoring dan Kontrol Proses Pencetakan")
        subtitle.setStyleSheet("""
            QLabel {
                font-size: 16px;
                color: #BBDEFB;
            }
        """)
        title_time_layout.addWidget(subtitle)
        
        # Waktu
        self.time_label = QLabel()
        self.time_label.setStyleSheet("""
            QLabel {
                font-size: 14px;
                color: #BBDEFB;
                margin-top: 5px;
            }
        """)
        title_time_layout.addWidget(self.time_label)
        
        header_layout.addLayout(title_time_layout)
        
        # Animasi header
        self.animate_header(header_frame)
        
        main_layout.addWidget(header_frame)
        
        # Frame untuk tombol-tombol
        button_frame = QFrame()
        button_frame.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 12px;
                padding: 20px;
            }
        """)
        
        # Layout untuk tombol-tombol
        button_layout = QGridLayout(button_frame)
        button_layout.setSpacing(20)
        
        # Tombol-tombol menu
        buttons = [
            ("Koneksi Arduino", self.show_arduino_connection, "#FF9800"),
            ("Training AI", self.show_training_ai, "#4CAF50"),
            ("Evaluasi Model", self.show_model_evaluation, "#2196F3"),
            ("Tes Prediksi", self.show_prediction_test, "#9C27B0"),
            ("Exit", self.close, "#FF0000")
        ]
        
        # Tambahkan tombol ke layout dengan animasi
        for i, (text, func, color) in enumerate(buttons):
            btn = QPushButton(text)
            btn.setProperty('color', color)
            btn.setStyleSheet(f"""
                QPushButton {{
                    background-color: {color};
                    color: white;
                    border: none;
                    border-radius: 8px;
                    padding: 12px 24px;
                    font-size: 14px;
                    font-weight: bold;
                }}
                QPushButton:hover {{
                    background-color: {color}99;
                }}
                QPushButton:pressed {{
                    background-color: {color}66;
                    padding-top: 14px;
                    padding-bottom: 10px;
                }}
            """)
            btn.clicked.connect(func)
            button_layout.addWidget(btn, i//3, i%3)
            self.animate_button(btn)
        
        main_layout.addWidget(button_frame)
        
        # Set scroll area
        scroll.setWidget(self.central_widget)
        self.setCentralWidget(scroll)
        
        # Timer untuk update waktu
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_time)
        self.timer.start(1000)  # Update setiap 1 detik
        self.update_time()  # Update waktu pertama kali
    
    def animate_header(self, widget):
        # Pastikan widget sudah memiliki ukuran yang benar
        widget.adjustSize()
        # Simpan ukuran akhir
        final_size = widget.size()
        # Set ukuran awal ke 0
        widget.setFixedSize(0, 0)
        # Buat animasi
        animation = QPropertyAnimation(widget, b"minimumSize")
        animation.setDuration(1000)
        animation.setStartValue(QSize(0, 0))
        animation.setEndValue(final_size)
        animation.setEasingCurve(QEasingCurve.OutBack)
        animation.start()
    
    def animate_button(self, button):
        # Simpan posisi akhir
        final_pos = button.pos()
        # Set posisi awal (sedikit ke bawah)
        button.move(button.x(), button.y() + 5)
        # Buat animasi
        animation = QPropertyAnimation(button, b"pos")
        animation.setDuration(200)  # Durasi lebih cepat
        animation.setStartValue(button.pos())
        animation.setEndValue(final_pos)
        animation.setEasingCurve(QEasingCurve.OutBack)
        animation.start()
        
        # Tambahkan efek hover yang lebih halus
        button.setStyleSheet(f"""
            QPushButton {{
                background-color: {button.property('color')};
                color: white;
                border: none;
                border-radius: 8px;
                padding: 12px 24px;
                font-size: 14px;
                font-weight: bold;
            }}
            QPushButton:hover {{
                background-color: {button.property('color')}99;
            }}
            QPushButton:pressed {{
                background-color: {button.property('color')}66;
                padding-top: 14px;
                padding-bottom: 10px;
            }}
        """)
    
    def show_arduino_connection(self):
        dialog = ArduinoConnectionDialog(self)
        dialog.exec_()
    
    def show_training_ai(self):
        # Widget utama untuk training AI
        training_widget = QWidget()
        layout = QVBoxLayout(training_widget)
        layout.setSpacing(10)
        # Frame untuk training
        train_frame = QFrame()
        train_frame.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 12px;
                padding: 15px;
            }
        """)
        train_layout = QVBoxLayout(train_frame)
        # Judul
        title = QLabel("Training Model AI")
        title.setStyleSheet("""
            QLabel {
                font-size: 18px;
                font-weight: bold;
                color: #333;
                margin-bottom: 10px;
            }
        """)
        train_layout.addWidget(title)
        # Form untuk training
        form_layout = QFormLayout()
        # Input file data
        self.data_file_input = QLineEdit()
        self.data_file_input.setPlaceholderText("Pilih file data (.xlsx atau .csv)")
        self.data_file_input.setReadOnly(True)
        # Tombol browse
        browse_btn = QPushButton("Browse")
        browse_btn.setStyleSheet("""
            QPushButton {
                background-color: #2196F3;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 5px 10px;
            }
            QPushButton:hover {
                background-color: #1976D2;
            }
        """)
        browse_btn.clicked.connect(self.browse_data_file)
        # Layout untuk input file dan tombol browse
        file_layout = QHBoxLayout()
        file_layout.addWidget(self.data_file_input)
        file_layout.addWidget(browse_btn)
        form_layout.addRow("File Data:", file_layout)
        # Input nama model
        self.model_name_input = QLineEdit()
        self.model_name_input.setPlaceholderText("Masukkan nama model (contoh: model_cetak_1)")
        form_layout.addRow("Nama Model:", self.model_name_input)
        # Combo box untuk validasi
        self.validation_combo = QComboBox()
        self.validation_combo.addItems(["5-fold", "10-fold", "Leave-One-Out"])
        form_layout.addRow("Validasi:", self.validation_combo)
        
        # Tombol/ikon untuk popup parameter tambahan
        self.toggle_advanced_btn = QPushButton("Parameter Tambahan ⚙️")
        self.toggle_advanced_btn.setStyleSheet("""
            QPushButton {
                background-color: #E0E0E0;
                color: #333;
                border: none;
                border-radius: 6px;
                padding: 6px 14px;
                font-size: 13px;
                font-weight: bold;
            }
            QPushButton:pressed {
                background-color: #BDBDBD;
            }
        """)
        self.toggle_advanced_btn.clicked.connect(self.show_advanced_param_dialog)
        form_layout.addRow(self.toggle_advanced_btn)
        train_layout.addLayout(form_layout)
        # Progress bar
        self.progress_bar = QProgressBar()
        self.progress_bar.setStyleSheet("""
            QProgressBar {
                border: 2px solid #2196F3;
                border-radius: 5px;
                text-align: center;
            }
            QProgressBar::chunk {
                background-color: #2196F3;
            }
        """)
        self.progress_bar.setVisible(False)
        train_layout.addWidget(self.progress_bar)
        # Area status tahapan preprocessing/training
        self.status_label = QLabel()
        self.status_label.setStyleSheet("font-size: 12px; color: #333; margin-top: 8px; margin-bottom: 8px;")
        self.status_label.setWordWrap(True)
        train_layout.addWidget(self.status_label)
        # Area hasil
        self.result_label = QLabel()
        self.result_label.setStyleSheet("""
            QLabel {
                font-size: 12px;
                color: #333;
                margin-top: 10px;
                padding: 8px;
                background-color: #F5F5F5;
                border-radius: 6px;
            }
        """)
        self.result_label.setWordWrap(True)
        train_layout.addWidget(self.result_label)
        # Tombol training
        train_btn = QPushButton("Train Model")
        train_btn.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                border: none;
                border-radius: 6px;
                padding: 8px 16px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #388E3C;
            }
        """)
        train_btn.clicked.connect(self.train_ai_model)
        train_layout.addWidget(train_btn)
        layout.addWidget(train_frame)
        # Tombol kembali
        back_btn = QPushButton("Kembali ke Menu Utama")
        back_btn.setStyleSheet("""
            QPushButton {
                background-color: #2196F3;
                color: white;
                border: none;
                border-radius: 6px;
                padding: 8px 16px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #1976D2;
            }
        """)
        back_btn.clicked.connect(self.show_main_menu)
        layout.addWidget(back_btn)
        self.setCentralWidget(training_widget)
        # --- Penyesuaian ukuran otomatis ---
        screen = QApplication.desktop().screenGeometry()
        max_width = screen.width() - 40
        max_height = screen.height() - 40
        self.resize(min(900, max_width), min(700, max_height))
        self.setMinimumSize(700, 500)
        self.setMaximumSize(max_width, max_height)
        self.center_window()
    
    def show_model_evaluation(self):
        # Widget utama untuk evaluasi model
        eval_widget = QWidget()
        layout = QHBoxLayout(eval_widget)  # Horizontal
        # Area kiri: hasil evaluasi (teks)
        left_frame = QFrame()
        left_layout = QVBoxLayout(left_frame)
        # Frame untuk evaluasi
        eval_frame = QFrame()
        eval_frame.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 12px;
                padding: 15px;
            }
        """)
        eval_layout = QVBoxLayout(eval_frame)
        # Judul
        title = QLabel("Evaluasi Model AI")
        title.setStyleSheet("""
            QLabel {
                font-size: 18px;
                font-weight: bold;
                color: #333;
                margin-bottom: 10px;
            }
        """)
        eval_layout.addWidget(title)
        # Form untuk evaluasi
        form_layout = QFormLayout()
        # Combo box untuk memilih model
        self.model_combo = QComboBox()
        self.model_combo.addItems(self.get_saved_models())
        form_layout.addRow("Pilih Model:", self.model_combo)
        eval_layout.addLayout(form_layout)
        # Area hasil evaluasi (hanya muncul setelah evaluasi)
        self.eval_result = QLabel()
        self.eval_result.setStyleSheet("""
            QLabel {
                font-size: 12px;
                color: #333;
                margin-top: 10px;
                padding: 8px;
                background-color: #F5F5F5;
                border-radius: 6px;
            }
        """)
        self.eval_result.setWordWrap(True)
        self.eval_result.setVisible(False)  # Sembunyikan dulu
        # Bungkus dengan QScrollArea agar bisa discroll
        self.eval_result_scroll = QScrollArea()
        self.eval_result_scroll.setWidgetResizable(True)
        self.eval_result_scroll.setWidget(self.eval_result)
        self.eval_result_scroll.setMinimumHeight(180)
        eval_layout.addWidget(self.eval_result_scroll)
        # Tombol evaluasi
        eval_btn = QPushButton("Evaluasi Model")
        eval_btn.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                border: none;
                border-radius: 6px;
                padding: 8px 16px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #388E3C;
            }
        """)
        eval_btn.clicked.connect(self.evaluate_model)
        eval_layout.addWidget(eval_btn)
        # Tombol visualisasi pohon keputusan
        tree_btn = QPushButton("Lihat Pohon Keputusan")
        tree_btn.setStyleSheet("""
            QPushButton {
                background-color: #FF9800;
                color: white;
                border: none;
                border-radius: 6px;
                padding: 8px 16px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #F57C00;
            }
        """)
        tree_btn.clicked.connect(self.show_decision_tree)
        eval_layout.addWidget(tree_btn)
        # Tombol ekspor hasil
        export_btn = QPushButton("Ekspor Hasil")
        export_btn.setStyleSheet("""
            QPushButton {
                background-color: #2196F3;
                color: white;
                border: none;
                border-radius: 6px;
                padding: 8px 16px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #1976D2;
            }
        """)
        export_btn.clicked.connect(self.export_evaluation)
        eval_layout.addWidget(export_btn)
        left_layout.addWidget(eval_frame)
        # Tombol kembali
        back_btn = QPushButton("Kembali ke Menu Utama")
        back_btn.setStyleSheet("""
            QPushButton {
                background-color: #2196F3;
                color: white;
                border: none;
                border-radius: 6px;
                padding: 8px 16px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #1976D2;
            }
        """)
        back_btn.clicked.connect(self.show_main_menu)
        left_layout.addWidget(back_btn)
        layout.addWidget(left_frame, 2)
        # Area kanan: confusion matrix dalam QScrollArea
        self.cm_area = QFrame()
        self.cm_area.setStyleSheet("background: transparent;")
        self.cm_area_layout = QVBoxLayout(self.cm_area)
        # Tambahkan tombol ringkasan di kanan atas
        summary_btn_layout = QHBoxLayout()
        summary_btn_layout.setAlignment(Qt.AlignRight)
        self.summary_btn = QPushButton("Tampilkan Ringkasan")
        self.summary_btn.setStyleSheet("""
            QPushButton {
                background-color: #FF9800;
                color: white;
                border: none;
                border-radius: 6px;
                padding: 6px 14px;
                font-size: 13px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #F57C00;
            }
        """)
        self.summary_btn.clicked.connect(self.show_model_summary_dialog)
        summary_btn_layout.addWidget(self.summary_btn)
        self.cm_area_layout.addLayout(summary_btn_layout)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(self.cm_area)
        layout.addWidget(scroll, 1)
        self.setCentralWidget(eval_widget)
        # Atur ukuran window agar proporsional dan di tengah
        screen = QApplication.desktop().screenGeometry()
        max_width = screen.width() - 40
        max_height = screen.height() - 40
        self.resize(min(1100, max_width), min(650, max_height))
        self.setMinimumSize(800, 500)
        self.setMaximumSize(max_width, max_height)
        self.center_window()
    
    def show_model_summary_dialog(self):
        # Dialog ringkasan model
        dialog = QDialog(self)
        dialog.setWindowTitle("Ringkasan Evaluasi Model AI")
        dialog.setMinimumWidth(480)
        layout = QVBoxLayout(dialog)
        summary_text = QTextEdit()
        summary_text.setReadOnly(True)
        summary_text.setStyleSheet("font-size: 13px; background: #f8f8f8; border-radius: 6px; padding: 10px;")
        summary_text.setText(self.generate_model_summary())
        layout.addWidget(summary_text)
        close_btn = QPushButton("Tutup")
        close_btn.clicked.connect(dialog.accept)
        layout.addWidget(close_btn)
        dialog.exec_()

    def generate_model_summary(self):
        # Ambil hasil evaluasi terakhir
        try:
            model_name = self.model_combo.currentText()
            from ai_model import ProductDefectPredictor
            predictor = ProductDefectPredictor()
            results = predictor.evaluate_model(model_name)
            if 'error' in results:
                return f"Terjadi kesalahan: {results['error']}"
            # Ambil metrik utama
            akurasi = results.get('accuracy', 0)
            f1 = results.get('f1_score', 0)
            cm = results.get('confusion_matrix', None)
            labels = results.get('confusion_labels', ['Cacat Berat', 'Cacat Ringan', 'Bagus'])
            probas = results.get('probabilities', {})
            # Buat ringkasan
            summary = f"Model AI '{model_name}' telah dievaluasi menggunakan data uji yang telah dipisahkan saat training. "
            summary += f"Model ini mampu mengklasifikasikan produk ke dalam tiga kategori utama: Cacat Berat, Cacat Ringan, dan Bagus. "
            summary += f"\n\nBerdasarkan hasil evaluasi, model memperoleh akurasi sebesar {akurasi*100:.2f}% dan F1-score {f1:.2f}. "
            if cm is not None:
                total = int(cm.sum())
                summary += f"Confusion matrix menunjukkan distribusi prediksi model terhadap label asli. Dari total {total} sampel, model mampu mengidentifikasi setiap kelas dengan baik. "
            if probas:
                summary += "\n\nProbabilitas rata-rata prediksi untuk masing-masing kelas adalah: "
                for k, v in probas.items():
                    idx = int(k)-1 if k.isdigit() else 0
                    label = labels[idx] if idx < len(labels) else k
                    summary += f"{label} ({k}): {v:.2f}, "
                summary = summary.rstrip(', ')
            summary += "\n\nSecara keseluruhan, model AI ini sudah sangat baik dalam membedakan produk cacat dan bagus, serta dapat diandalkan untuk proses monitoring dan kontrol pencetakan biji catur. Namun, evaluasi lebih lanjut pada data nyata tetap disarankan untuk memastikan performa model secara konsisten di lingkungan produksi."
            # HAPUS bagian kesimpulan otomatis dari ringkasan
            return summary
        except Exception as e:
            return f"Gagal membuat ringkasan: {str(e)}"
    
    def show_prediction_test(self):
        # Widget utama untuk tes prediksi
        test_widget = QWidget()
        layout = QVBoxLayout(test_widget)
        
        # Frame untuk tes prediksi
        test_frame = QFrame()
        test_frame.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 12px;
                padding: 15px;
            }
        """)
        
        test_layout = QVBoxLayout(test_frame)
        
        # Judul
        title = QLabel("Tes Prediksi Model AI")
        title.setStyleSheet("""
            QLabel {
                font-size: 18px;
                font-weight: bold;
                color: #333;
                margin-bottom: 10px;
            }
        """)
        test_layout.addWidget(title)
        
        # Form untuk input
        form_layout = QFormLayout()
        
        # Combo box untuk memilih model
        self.pred_model_combo = QComboBox()
        self.pred_model_combo.addItems(self.get_saved_models())
        form_layout.addRow("Pilih Model:", self.pred_model_combo)
        
        # Input suhu
        self.temp_input = QLineEdit()
        self.temp_input.setPlaceholderText("Masukkan suhu")
        form_layout.addRow("Suhu:", self.temp_input)
        
        # Input pressure
        self.pressure_input = QLineEdit()
        self.pressure_input.setPlaceholderText("Masukkan pressure")
        form_layout.addRow("Pressure:", self.pressure_input)
        
        # Input kemiringan
        self.tilt_input = QLineEdit()
        self.tilt_input.setPlaceholderText("Masukkan kemiringan")
        form_layout.addRow("Kemiringan:", self.tilt_input)
        
        test_layout.addLayout(form_layout)
        
        # Area hasil prediksi
        self.pred_result = QLabel()
        self.pred_result.setStyleSheet("""
            QLabel {
                font-size: 12px;
                color: #333;
                margin-top: 10px;
                padding: 8px;
                background-color: #F5F5F5;
                border-radius: 6px;
            }
        """)
        self.pred_result.setWordWrap(True)
        test_layout.addWidget(self.pred_result)
        
        # Tombol prediksi
        pred_btn = QPushButton("Prediksi")
        pred_btn.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                border: none;
                border-radius: 6px;
                padding: 8px 16px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #388E3C;
            }
        """)
        pred_btn.clicked.connect(self.perform_prediction)
        test_layout.addWidget(pred_btn)
        
        layout.addWidget(test_frame)
        
        # Tombol kembali
        back_btn = QPushButton("Kembali ke Menu Utama")
        back_btn.setStyleSheet("""
            QPushButton {
                background-color: #2196F3;
                color: white;
                border: none;
                border-radius: 6px;
                padding: 8px 16px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #1976D2;
            }
        """)
        back_btn.clicked.connect(self.show_main_menu)
        layout.addWidget(back_btn)
        
        self.setCentralWidget(test_widget)
    
    def get_saved_models(self):
        # Fungsi untuk mendapatkan daftar model yang tersimpan
        model_dir = "model_ai"
        if not os.path.exists(model_dir):
            os.makedirs(model_dir)
        return [f for f in os.listdir(model_dir) if f.endswith('.pkl')]
        
    def browse_data_file(self):
        file_name, _ = QFileDialog.getOpenFileName(
            self,
            "Pilih File Data",
            "",
            "Excel Files (*.xlsx);;CSV Files (*.csv)"
        )
        if file_name:
            self.data_file_input.setText(file_name)
            
    def train_ai_model(self):
        try:
            file_path = self.data_file_input.text()
            model_name = self.model_name_input.text()
            if not file_path or not model_name:
                self.result_label.setText("Mohon lengkapi file data dan nama model.")
                return
            # --- Cek data sebelum training ---
            import pandas as pd
            try:
                if file_path.endswith('.xlsx'):
                    df = pd.read_excel(file_path)
                else:
                    df = pd.read_csv(file_path)
            except Exception as e:
                QMessageBox.critical(self, "Error Data", f"Gagal membaca file data: {str(e)}")
                return
            # Cek data error/sampah
            error_msgs = []
            if df.isnull().any().any():
                error_msgs.append("Ada data kosong (missing value)!")
            if (df['suhu'] < 100).any() or (df['suhu'] > 300).any():
                error_msgs.append("Ada nilai suhu di luar rentang normal (100-300)!")
            if (df['pressure'] < 0).any() or (df['pressure'] > 300).any():
                error_msgs.append("Ada nilai pressure di luar rentang normal (0-300)!")
            if (df['kemiringan'] < 0).any() or (df['kemiringan'] > 90).any():
                error_msgs.append("Ada nilai kemiringan di luar rentang normal (0-90)!")
            if 'label' in df.columns and (df['label'].isnull() | (df['label'] == '')).any():
                error_msgs.append("Ada label kosong!")
            if error_msgs:
                QMessageBox.critical(self, "Data Error/Sampah", "\n".join(error_msgs) + "\n\nSilakan perbaiki data sebelum training.")
                return
            # Tampilkan progress bar
            self.progress_bar.setVisible(True)
            self.progress_bar.setValue(0)
            # Tampilkan status tahapan
            self.status_label.setText("1. Data Cleaning (Missing value, Inconsistent, Duplikasi)...")
            QApplication.processEvents()
            from ai_model import ProductDefectPredictor
            predictor = ProductDefectPredictor()
            import time
            self.progress_bar.setValue(10)
            self.status_label.setText("2. Mendeteksi Outlier...")
            QApplication.processEvents()
            time.sleep(0.2)
            self.progress_bar.setValue(20)
            self.status_label.setText("3. Mengubah kategorikal data dalam bentuk numerik...")
            QApplication.processEvents()
            time.sleep(0.2)
            self.progress_bar.setValue(30)
            self.status_label.setText("4. Scaling, Normalisasi, Standarisasi jika diperlukan...")
            QApplication.processEvents()
            time.sleep(0.2)
            self.progress_bar.setValue(40)
            self.status_label.setText("5. Feature Selection / Dimensionality Reduction...")
            QApplication.processEvents()
            time.sleep(0.2)
            self.progress_bar.setValue(50)
            self.status_label.setText("Training Model...")
            QApplication.processEvents()
            # Ambil epoch dari atribut, bukan dari field
            try:
                total_epoch = int(self.epoch_value)
            except:
                total_epoch = 10
            # Training model dengan progress epoch
            def update_progress(value, epoch=None):
                self.progress_bar.setValue(value)
                if epoch is not None:
                    self.status_label.setText(f"Training Model: Epoch {epoch}/{total_epoch} selesai")
                QApplication.processEvents()
            success, msg = predictor.train_model(
                file_path, 
                model_name,
                validation_type=self.validation_combo.currentText(),
                progress_callback=update_progress,
                total_epoch=total_epoch
            )
            self.progress_bar.setValue(100)
            self.status_label.setText("Training selesai!")
            if success:
                self.result_label.setText("Model berhasil di-training!")
                QMessageBox.information(self, "Sukses", f"Model '{model_name}' berhasil disimpan.")
            else:
                self.result_label.setText(f"Error dalam training model: {msg}")
                QMessageBox.critical(self, "Gagal", f"Model '{model_name}' gagal disimpan!")
        except Exception as e:
            self.result_label.setText(f"Terjadi kesalahan: {str(e)}")
        finally:
            self.progress_bar.setVisible(False)
    
    def evaluate_model(self):
        try:
            model_name = self.model_combo.currentText()
            if not model_name:
                self.eval_result.setText("Mohon pilih model yang akan dievaluasi.")
                self.eval_result.setVisible(True)
                return
            from ai_model import ProductDefectPredictor
            predictor = ProductDefectPredictor()
            results = predictor.evaluate_model(model_name)
            if 'error' in results:
                self.eval_result.setText(f"Terjadi kesalahan: {results['error']}")
                self.eval_result.setVisible(True)
                return
            eval_text = f"<b>Hasil Evaluasi Model:</b> {model_name}<br><br>"
            eval_text += f"<b>Probabilitas Kelas:</b><br>"
            for class_name, prob in results.get('probabilities', {}).items():
                eval_text += f"{class_name}: {prob:.2f}<br>"
            eval_text += f"<br><b>Akurasi:</b> {results['accuracy']*100:.2f}%<br>"
            eval_text += f"<b>F1-score:</b> {results['f1_score']:.2f}<br>"
            eval_text += f"<br><b>Laporan Klasifikasi:</b><br>"
            eval_text += f"<pre style='font-family:Consolas,monospace;font-size:12px;background:#f8f8f8;padding:6px;border-radius:4px;margin-top:2px;'>{results.get('report', '')}</pre>"
            # Tambahkan kesimpulan otomatis (hanya di panel utama)
            accuracy = results['accuracy'] * 100
            f1 = results['f1_score']
            if accuracy >= 85 and f1 >= 0.80:
                kesimpulan = "<span style='color:green;'><b>Model AI ini memiliki performa yang baik dan layak digunakan untuk prediksi pada data nyata.</b></span>"
            else:
                kesimpulan = "<span style='color:red;'><b>Model AI ini masih perlu perbaikan karena performanya belum optimal.</b></span>"
            eval_text += f"<br><br><b>Kesimpulan:</b><br>{kesimpulan}"
            self.eval_result.setText(eval_text)
            self.eval_result.setVisible(True)
            self.render_confusion_matrix(results['confusion_matrix'], results['confusion_labels'])
        except Exception as e:
            self.eval_result.setText(f"Terjadi kesalahan: {str(e)}")
            self.eval_result.setVisible(True)
    
    def render_confusion_matrix(self, cm, labels):
        # Bersihkan area kanan
        for i in reversed(range(self.cm_area_layout.count())):
            widget = self.cm_area_layout.itemAt(i).widget()
            if widget is not None:
                widget.setParent(None)
        from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
        import matplotlib.pyplot as plt
        # Judul
        title = QLabel("Confusion Matrix")
        title.setStyleSheet("font-size: 16px; font-weight: bold; margin-bottom: 8px;")
        # Label string untuk sumbu X/Y
        string_labels = ["Cacat Berat", "Cacat Ringan", "Bagus"]
        # Buat heatmap matplotlib
        fig, ax = plt.subplots(figsize=(5, 4))
        im = ax.imshow(cm, interpolation='nearest', cmap=plt.cm.Blues)
        # Label sumbu (pakai string_labels)
        ax.set_xticks(range(3))
        ax.set_yticks(range(3))
        ax.set_xticklabels(string_labels)
        ax.set_yticklabels(string_labels)
        ax.set_xlabel('Prediksi AI', fontsize=12)
        ax.set_ylabel('Label Asli', fontsize=12)
        # Tampilkan angka di setiap sel
        fmt = 'd'
        thresh = cm.max() / 2.
        for i in range(cm.shape[0]):
            for j in range(cm.shape[1]):
                ax.text(j, i, format(cm[i, j], fmt),
                        ha="center", va="center",
                        color="white" if cm[i, j] > thresh else "black",
                        fontsize=12)
        fig.tight_layout(pad=2.0)
        # Tambahkan colorbar
        cbar = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
        cbar.ax.tick_params(labelsize=10)
        # Buat canvas
        canvas = FigureCanvas(fig)
        canvas.setMinimumWidth(320)
        canvas.setMinimumHeight(320)
        # Tambahkan ke layout area kanan
        self.cm_area_layout.addWidget(title)
        self.cm_area_layout.addWidget(canvas)
    
    def export_evaluation(self):
        try:
            model_name = self.model_combo.currentText()
            if not model_name:
                QMessageBox.warning(self, "Error", "Mohon pilih model yang akan dievaluasi.")
                return
                
            # Inisialisasi model AI
            from ai_model import ProductDefectPredictor
            predictor = ProductDefectPredictor()
            
            # Dapatkan hasil evaluasi
            results = predictor.evaluate_model(model_name)
            
            # Dialog untuk memilih lokasi penyimpanan
            file_name, _ = QFileDialog.getSaveFileName(
                self,
                "Simpan Hasil Evaluasi",
                "",
                "Excel Files (*.xlsx);;All Files (*.*)"
            )
            
            if file_name:
                # Export ke Excel
                import pandas as pd
                
                # Buat DataFrame untuk hasil evaluasi
                eval_data = {
                    'Metric': ['Akurasi', 'F1-score'],
                    'Value': [results['accuracy'], results['f1_score']]
                }
                df_eval = pd.DataFrame(eval_data)
                
                # Buat DataFrame untuk probabilitas
                prob_data = {
                    'Kelas': list(results['probabilities'].keys()),
                    'Probabilitas': list(results['probabilities'].values())
                }
                df_prob = pd.DataFrame(prob_data)
                
                # Buat DataFrame untuk confusion matrix (otomatis sesuai jumlah kelas)
                labels = results['confusion_labels']
                cm = results['confusion_matrix']
                cm_data = {
                    'Predicted': [],
                    'Actual': [],
                    'Count': []
                }
                for i, pred_label in enumerate(labels):
                    for j, actual_label in enumerate(labels):
                        cm_data['Predicted'].append(pred_label)
                        cm_data['Actual'].append(actual_label)
                        cm_data['Count'].append(cm[j, i])  # baris: actual, kolom: prediksi
                df_cm = pd.DataFrame(cm_data)
                
                # Simpan ke Excel dengan multiple sheets
                with pd.ExcelWriter(file_name) as writer:
                    df_eval.to_excel(writer, sheet_name='Evaluasi', index=False)
                    df_prob.to_excel(writer, sheet_name='Probabilitas', index=False)
                    df_cm.to_excel(writer, sheet_name='Confusion Matrix', index=False)
            
            QMessageBox.information(
                self,
                    "Sukses",
                    f"Hasil evaluasi berhasil diekspor ke:\n{file_name}"
                )
                
        except Exception as e:
            QMessageBox.critical(
                self,
                "Error",
                f"Gagal mengekspor hasil evaluasi: {str(e)}"
            )
    
    def perform_prediction(self):
        try:
            model_name = self.pred_model_combo.currentText()
            if not model_name:
                self.pred_result.setText("Mohon pilih model yang akan digunakan.")
                return
                
            # Ambil input
            suhu = float(self.temp_input.text())
            pressure = float(self.pressure_input.text())
            kemiringan = float(self.tilt_input.text())
            
            # Inisialisasi model AI
            from ai_model import ProductDefectPredictor
            predictor = ProductDefectPredictor()
            # Load model sesuai nama model
            model_dir = "model_ai"
            if not os.path.exists(model_dir):
                os.makedirs(model_dir)
            model_path = os.path.join(model_dir, f"{model_name}")
            scaler_path = os.path.join(model_dir, f"{model_name.replace('.pkl', '_scaler.pkl')}")
            if not os.path.exists(model_path) or not os.path.exists(scaler_path):
                self.pred_result.setText("Model atau scaler tidak ditemukan.")
                return
            predictor.model = joblib.load(model_path)
            predictor.scaler = joblib.load(scaler_path)
            # Lakukan prediksi
            import pandas as pd
            input_df = pd.DataFrame([[suhu, pressure, kemiringan]], columns=['suhu', 'pressure', 'kemiringan'])
            result = predictor.predict(input_df)
            # Tampilkan hasil
            pred_text = f"Hasil Prediksi:\n"
            pred_text += f"Kelas: {result['prediction']}\n"
            if 'confidence' in result:
                pred_text += f"Tingkat Kepercayaan: {result['confidence']*100:.2f}%\n"
            if 'probabilities' in result:
                pred_text += f"Probabilitas:\n"
                for class_name, prob in result['probabilities'].items():
                    pred_text += f"{class_name}: {prob:.2f}\n"
            self.pred_result.setText(pred_text)
        except ValueError:
            self.pred_result.setText("Mohon masukkan nilai numerik yang valid untuk semua input.")
        except Exception as e:
            self.pred_result.setText(f"Terjadi kesalahan: {str(e)}")

    def update_time(self):
        try:
            if hasattr(self, 'time_label') and self.time_label is not None:
                from datetime import datetime
                current_time = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
                self.time_label.setText(f"Waktu: {current_time}")
        except RuntimeError:
            # Jika label sudah dihapus, hentikan timer
            if hasattr(self, 'timer'):
                self.timer.stop()
                
    def closeEvent(self, event):
        self.db.close()
        event.accept()

    def show_advanced_param_dialog(self):
        dialog = AdvancedParameterDialog(
                self,
            epochs=self.epoch_value,
            batch_size=self.batch_value,
            lr=self.lr_value,
            optimizer=self.optimizer_value,
            loss=self.loss_value,
            activation=self.activation_value
        )
        if dialog.exec_() == QDialog.Accepted:
            vals = dialog.get_values()
            self.epoch_value = vals['epochs']
            self.batch_value = vals['batch_size']
            self.lr_value = vals['lr']
            self.optimizer_value = vals['optimizer']
            self.loss_value = vals['loss']
            self.activation_value = vals['activation'] 

    def show_decision_tree(self):
        try:
            model_name = self.model_combo.currentText()
            if not model_name:
                QMessageBox.warning(self, "Error", "Mohon pilih model yang akan dievaluasi.")
                return
            import joblib
            import matplotlib.pyplot as plt
            from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
            from sklearn.tree import plot_tree
            from PyQt5.QtWidgets import QInputDialog, QSizePolicy
            import os
            # Load model
            model_dir = "model_ai"
            model_path = os.path.join(model_dir, f"{model_name}")
            if not os.path.exists(model_path):
                QMessageBox.warning(self, "Error", "Model tidak ditemukan.")
                return
            model = joblib.load(model_path)
            # Cek apakah model RandomForest
            if not hasattr(model, 'estimators_'):
                QMessageBox.warning(self, "Error", "Model bukan Random Forest.")
                return
            n_trees = len(model.estimators_)
            # Dialog pilih pohon ke berapa
            idx, ok = QInputDialog.getInt(self, "Pilih Pohon", f"Model ini memiliki {n_trees} pohon. Pilih pohon ke berapa (0 - {n_trees-1}):", 0, 0, n_trees-1, 1)
            if not ok:
                return
            estimator = model.estimators_[idx]
            # Buat dialog popup
            dialog = QDialog(self)
            dialog.setWindowTitle(f"Visualisasi Pohon Keputusan (Tree {idx})")
            dialog.setWindowFlags(dialog.windowFlags() | Qt.Window)  # Agar bisa di-resize
            dialog.setWindowState(Qt.WindowMaximized)
            dialog.showMaximized()  # Otomatis maximize saat muncul
            layout = QVBoxLayout(dialog)
            fig, ax = plt.subplots(figsize=(12, 6))
            # Plot pohon, simpan semua teks node asli
            tree_plot = plot_tree(
                estimator,
                filled=True,
                feature_names=['suhu', 'pressure', 'kemiringan'],
                class_names=['Cacat Berat', 'Cacat Ringan', 'Bagus'],
                rounded=True,
                fontsize=10,
                ax=ax
            )
            fig.tight_layout()
            # Simpan teks asli node
            node_texts = [t.get_text() for t in ax.texts]
            # Ubah label node hanya jadi class saja
            for t in ax.texts:
                for line in t.get_text().split('\n'):
                    if line.startswith('class = '):
                        t.set_text(line.replace('class = ', '').strip())
                        break
            canvas = FigureCanvas(fig)
            canvas.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
            layout.addWidget(canvas)
            close_btn = QPushButton("Tutup")
            close_btn.clicked.connect(dialog.accept)
            layout.addWidget(close_btn)
            dialog.setMinimumWidth(900)
            dialog.setMinimumHeight(500)
            # Event klik pada node: tampilkan info lengkap
            def on_click(event):
                if event.inaxes != ax:
                    return
                for i, t in enumerate(ax.texts):
                    bbox = t.get_window_extent(canvas.get_renderer())
                    if bbox.contains(event.x, event.y):
                        info = node_texts[i].replace('\n', '<br>')
                        QMessageBox.information(dialog, "Info Node", f"<b>Detail Node:</b><br>{info}", QMessageBox.Ok)
                        break
            canvas.mpl_connect('button_press_event', on_click)
            dialog.exec_()
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Gagal menampilkan pohon keputusan: {str(e)}") 