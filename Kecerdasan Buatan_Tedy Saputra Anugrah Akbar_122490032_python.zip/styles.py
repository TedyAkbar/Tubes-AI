# Style untuk aplikasi
APP_STYLE = """
QMainWindow {
    background-color: #f5f5f5;
}

QWidget {
    font-family: 'Segoe UI', Arial, sans-serif;
}

QPushButton {
    padding: 12px 24px;
    font-size: 14px;
    font-weight: bold;
    background-color: #2196F3;
    color: white;
    border: none;
    border-radius: 8px;
    min-width: 200px;
    min-height: 50px;
}

QPushButton:hover {
    background-color: #1976D2;
}

QPushButton:pressed {
    background-color: #0D47A1;
}

QPushButton:disabled {
    background-color: #BDBDBD;
}

QLabel {
    font-size: 16px;
    color: #333;
}

QFrame {
    background-color: white;
    border-radius: 12px;
    padding: 20px;
}

QTableWidget {
    background-color: white;
    border-radius: 8px;
    gridline-color: #E0E0E0;
}

QHeaderView::section {
    background-color: #2196F3;
    color: white;
    padding: 8px;
    border: none;
    font-weight: bold;
}

QTableWidget::item {
    padding: 8px;
}

QTableWidget::item:selected {
    background-color: #BBDEFB;
    color: #000;
}

QLineEdit {
    padding: 8px;
    border: 2px solid #BDBDBD;
    border-radius: 8px;
    background-color: white;
}

QLineEdit:focus {
    border-color: #2196F3;
}

QComboBox {
    padding: 8px;
    border: 2px solid #BDBDBD;
    border-radius: 8px;
    background-color: white;
}

QComboBox:focus {
    border-color: #2196F3;
}

QSpinBox, QDoubleSpinBox {
    padding: 8px;
    border: 2px solid #BDBDBD;
    border-radius: 8px;
    background-color: white;
}

QSpinBox:focus, QDoubleSpinBox:focus {
    border-color: #2196F3;
}

QMessageBox {
    background-color: white;
}

QMessageBox QPushButton {
    min-width: 100px;
}

QStatusBar {
    background-color: #E0E0E0;
    color: #333;
    font-size: 12px;
}

/* Hover effect untuk tabel */
QTableWidget::item:hover {
    background-color: #E3F2FD;
}

/* Custom scrollbar */
QScrollBar:vertical {
    border: none;
    background-color: #F5F5F5;
    width: 10px;
    margin: 0px;
}

QScrollBar::handle:vertical {
    background-color: #BDBDBD;
    border-radius: 5px;
    min-height: 20px;
}

QScrollBar::handle:vertical:hover {
    background-color: #9E9E9E;
}

QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
    height: 0px;
}

QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {
    background: none;
}
""" 